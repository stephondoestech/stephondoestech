#######################
#  TERRAFORM SETTINGS #
#######################

alias tffmt="terraform fmt -check"
alias tfdiff="terraform fmt -diff"
alias tfval="terraform validate"