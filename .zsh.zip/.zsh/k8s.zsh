#####################
#  KUBECTL SETTINGS #
#####################

alias kbpo="kubectl get pods -A"
alias k8spods="kubectl get pods"