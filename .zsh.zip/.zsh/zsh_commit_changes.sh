#!/bin/zsh
cd `dirname "$0"`
cp $HOME/.zshrc .
tar -czvf zsh_config_backup.tar.gz *
cp $HOME/nytimes/stephon-nytimes/.zsh/zsh_config_backup.tar.gz 
cp $HOME/.zshrc .
git add .
git commit -m "Sync zsh config archive files"
git push origin
rm -f $HOME/nytimes/stephon-nytimes/zsh_config_backup.tar.gz