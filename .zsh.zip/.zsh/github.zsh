####################
# GITHUB SETTINGS  #
####################

export GITHUB_USERNAME="stephon-nytimes"
