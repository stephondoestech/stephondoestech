#######################
# GITHUB CREDENTIALS  #
#######################

# export GITHUB_TOKEN="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"
# export HOMEBREW_GITHUB_API_TOKEN="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"