####################
# PYTHON SETTINGS  #
####################
export PATH="/opt/homebrew/opt/python/libexec/bin:$PATH"

# test