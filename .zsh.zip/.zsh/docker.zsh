####################
#  DOCKER SETTINGS #
####################

# export DOCKER_DEFAULT_PLATFORM=linux/amd64
# export DOCKER_BUILDKIT=0 
# export COMPOSE_DOCKER_CLI_BUILD=0
alias dcb="DOCKER_DEFAULT_PLATFORM=linux/amd64 docker-compose build"
alias dcba="DOCKER_DEFAULT_PLATFORM=linux/amd64 docker-compose build app-silicon"
alias dcu="docker-compose up -d app-silicon"
alias dcd="docker-compose down"
alias und="unset DOCKER_DEFAULT_PLATFORM"