export PATH="/opt/homebrew/opt/dotnet@6/bin:$PATH"
