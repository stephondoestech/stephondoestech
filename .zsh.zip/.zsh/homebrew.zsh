#####################
# HOMEBREW SETTINGS #
#####################

# Set PATH, MANPATH, etc., for Homebrew.
eval "$(/opt/homebrew/bin/brew shellenv)"

export HOMEBREW_AUTO_UPDATE_SECS="86400"