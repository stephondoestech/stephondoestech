####################
#       ALIAS      #
####################

alias shell="exec zsh -l"
alias awslogin="aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 080387373610.dkr.ecr.us-east-1.amazonaws.com"
alias awsunsetenv="unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN"
alias dvspunset="unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_PROFILE"